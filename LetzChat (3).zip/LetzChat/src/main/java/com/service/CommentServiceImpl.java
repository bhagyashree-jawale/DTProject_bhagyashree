package com.service;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DAO.CommentDAO;
import com.DAO.ForumDaoInterface;
import com.model.Comment;

@Service
public class CommentServiceImpl  implements CommentService{
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	CommentDAO commentdao;

	public  CommentServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	
	public CommentServiceImpl(SessionFactory sf){
		this.sessionFactory=sf;
	}
	@Override
	public List<Comment> getList() {
		// TODO Auto-generated method stub
		return commentdao.getList();
	}

	@Override
	public void addComment(Comment com) {
		// TODO Auto-generated method stub
		commentdao.addComment(com);
	}

}
