package com.DAO;

import java.util.List;

import com.model.*;

public interface CommentDAO {
	public List<Comment> getList();
	public void addComment(Comment com);
	
}
